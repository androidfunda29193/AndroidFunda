package com.example.hp.myapplication;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    ImageView userImage;
    SeekBar seekBar;
    int step = 1;
    int max = 200;
    int min = 100;
    TextView height;
    String HeightInteger = "150";
    private int previousProcess = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        SetUpView();
        ManageAnimation();


    }

    private void SetUpView() {
        height = (TextView) findViewById(R.id.height);
        userImage = (ImageView) findViewById(R.id.userImage);
        seekBar = (SeekBar) findViewById(R.id.seekBar1);
    }

    private void ManageAnimation() {
        try {

            seekBar.setMax((max - min) / step);

            seekBar.setOnSeekBarChangeListener(
                    new SeekBar.OnSeekBarChangeListener() {
                        @Override
                        public void onStopTrackingTouch(SeekBar seekBar) {
                        }

                        @Override
                        public void onStartTrackingTouch(SeekBar seekBar) {
                        }

                        @Override
                        public void onProgressChanged(SeekBar seekBar, int progress,
                                                      boolean fromUser) {

                            double value = min + (progress * step);
                            if (value < 120) {
                                seekBar.setProgress(20);
                            } else {
                                ShowAnimation(progress, (int) value);


                            }
                        }
                    }
            );
            

        } catch (Exception ex) {
            System.out.println(ex);
        }
    }

    private void ShowAnimation(int progress, int value) {
        height.setText(String.valueOf(value) + " cm");
        HeightInteger = String.valueOf(value);
        ImageView userImage = (ImageView) findViewById(R.id.userImage);

        int height = (int) userImage.getMeasuredHeight();

        previousProcess = (progress - 20) * 4 + 10;

        ResizeAnimation animation = null;

        animation = new ResizeAnimation(userImage, LinearLayout.LayoutParams.WRAP_CONTENT,
                height, LinearLayout.LayoutParams.WRAP_CONTENT, ((progress * 10) - previousProcess));
        //1 second is enougth for animation duration run smoothly
        animation.setDuration(1000);
        animation.setAnimationListener(new Animation.AnimationListener() {

            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

            }
        });
        userImage.startAnimation(animation);
    }

}
